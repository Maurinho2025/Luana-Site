import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Menu, Calendar, Clock, MapPin, Phone, Star, SmileIcon as Tooth, Users, CheckCircle } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel"

function MobileNav() {
  return (
    <>
      <Sheet>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="md:hidden">
            <Menu className="h-6 w-6 text-[#8e6e55]" />
            <span className="sr-only">Toggle menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="right" className="bg-[#f4eae6] border-l-[#e0d2c6]">
          <div className="flex flex-col gap-6 py-6">
            <div className="flex items-center gap-2">
              
            </div>
            <nav className="flex flex-col gap-4">
              <Link href="#" className="text-[#8e6e55] hover:text-[#7d5e45] text-lg">
                Home
              </Link>
              <Link href="#services" className="text-[#8e6e55] hover:text-[#7d5e45] text-lg">
                Services
              </Link>
              <Link href="#about" className="text-[#8e6e55] hover:text-[#7d5e45] text-lg">
                About
              </Link>
              <Link href="#testimonials" className="text-[#8e6e55] hover:text-[#7d5e45] text-lg">
                Testimonials
              </Link>
              <Link href="#contact" className="text-[#8e6e55] hover:text-[#7d5e45] text-lg">
                Contact
              </Link>
            </nav>
            <Button className="w-full bg-[#8e6e55] hover:bg-[#7d5e45] text-white mt-4">Book Appointment</Button>
          </div>
        </SheetContent>
      </Sheet>
    </>
  )
}

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      {/* Navigation */}
      <header className="sticky top-0 z-40 border-b bg-[#f4eae6]">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
           <img src="/Logo.png" className="h-16 w-24" alt="" />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            <Link href="#" className="text-[#8e6e55] hover:underline">
              Home
            </Link>
            <Link href="#services" className="text-[#8e6e55] hover:underline">
              Services
            </Link>
            <Link href="#about" className="text-[#8e6e55] hover:underline">
              About
            </Link>
            <Link href="#testimonials" className="text-[#8e6e55] hover:underline">
              Testimonials
            </Link>
            <Link href="#contact" className="text-[#8e6e55] hover:underline">
              Contact
            </Link>
          </nav>

          {/* Mobile Navigation */}
          <div className="md:hidden flex items-center gap-4">
            <MobileNav />
          </div>

          <Button className="hidden md:flex bg-[#8e6e55] hover:bg-[#7d5e45] text-white">Book Appointment</Button>
        </div>
      </header>

      <main className="flex-1">
        {/* Top Carousel */}
        <section className="bg-[#f4eae6] py-4 md:py-6">
          <div className="container px-4 md:px-6">
            {/*Aqui a abaixo tem o elemento do carousel voce pode editar aqui colcoar os src das imagens no carousel*/}
            <Carousel className="w-full" opts={{ loop: true }}>
              <CarouselContent>
                {/* Slide 1 */}
                <CarouselItem>
                  <div className="relative h-[300px] md:h-[400px] lg:h-[500px] w-full overflow-hidden rounded-xl">
                    <img
                      src="/placeholder.svg?height=500&width=1200"
                      alt="Beautiful smile transformation"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-[#8e6e55]/80 to-transparent flex flex-col justify-center p-8 md:p-12">
                      <h2 className="text-2xl md:text-4xl font-bold text-white mb-4 max-w-md">
                        Transform Your Smile Today
                      </h2>
                      <p className="text-white/90 text-base md:text-lg mb-6 max-w-md">
                        Experience our premium cosmetic dentistry services with a free consultation.
                      </p>
                      <Button className="bg-white text-[#8e6e55] hover:bg-white/90 w-fit">
                        Book Free Consultation
                      </Button>
                    </div>
                  </div>
                </CarouselItem>

                {/* Slide 2 */}
                <CarouselItem>
                  <div className="relative h-[300px] md:h-[400px] lg:h-[500px] w-full overflow-hidden rounded-xl">
                    <img
                      src="/placeholder.svg?height=500&width=1200"
                      alt="Family dental care"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-[#8e6e55]/80 to-transparent flex flex-col justify-center p-8 md:p-12">
                      <h2 className="text-2xl md:text-4xl font-bold text-white mb-4 max-w-md">Family Dental Care</h2>
                      <p className="text-white/90 text-base md:text-lg mb-6 max-w-md">
                        Comprehensive dental services for the whole family in a comfortable environment.
                      </p>
                      <Button className="bg-white text-[#8e6e55] hover:bg-white/90 w-fit">Learn More</Button>
                    </div>
                  </div>
                </CarouselItem>

                {/* Slide 3 */}
                <CarouselItem>
                  <div className="relative h-[300px] md:h-[400px] lg:h-[500px] w-full overflow-hidden rounded-xl">
                    <img
                      src="/placeholder.svg?height=500&width=1200"
                      alt="Special offer"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-[#8e6e55]/80 to-transparent flex flex-col justify-center p-8 md:p-12">
                      <div className="bg-white/20 backdrop-blur-sm inline-block px-4 py-1 rounded-full text-white font-medium mb-4">
                        Limited Time Offer
                      </div>
                      <h2 className="text-2xl md:text-4xl font-bold text-white mb-4 max-w-md">
                        20% Off Teeth Whitening
                      </h2>
                      <p className="text-white/90 text-base md:text-lg mb-6 max-w-md">
                        Get a brighter smile for summer with our professional whitening services.
                      </p>
                      <Button className="bg-white text-[#8e6e55] hover:bg-white/90 w-fit">Claim Offer</Button>
                    </div>
                  </div>
                </CarouselItem>

                {/* Slide 4 */}
                <CarouselItem>
                  <div className="relative h-[300px] md:h-[400px] lg:h-[500px] w-full overflow-hidden rounded-xl bg-[#e0d2c6]">
                    <div className="absolute inset-0 flex flex-col md:flex-row items-center justify-between p-8 md:p-12">
                      <div className="md:w-1/2 mb-6 md:mb-0">
                        <h2 className="text-2xl md:text-4xl font-bold text-[#8e6e55] mb-4">Why Choose Us?</h2>
                        <ul className="space-y-3">
                          <li className="flex items-start gap-2">
                            <CheckCircle className="h-5 w-5 text-[#8e6e55] mt-1 flex-shrink-0" />
                            <span className="text-[#8e6e55]">State-of-the-art equipment</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle className="h-5 w-5 text-[#8e6e55] mt-1 flex-shrink-0" />
                            <span className="text-[#8e6e55]">Experienced dental professionals</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle className="h-5 w-5 text-[#8e6e55] mt-1 flex-shrink-0" />
                            <span className="text-[#8e6e55]">Comfortable, relaxing environment</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle className="h-5 w-5 text-[#8e6e55] mt-1 flex-shrink-0" />
                            <span className="text-[#8e6e55]">Affordable payment plans</span>
                          </li>
                        </ul>
                        <Button className="bg-[#8e6e55] text-white hover:bg-[#7d5e45] mt-6">Schedule Visit</Button>
                      </div>
                      <div className="md:w-1/2 flex justify-center">
                        <img
                          src="/placeholder.svg?height=300&width=300"
                          alt="Dental clinic"
                          className="rounded-full h-40 w-40 md:h-64 md:w-64 object-cover border-4 border-white shadow-lg"
                        />
                      </div>
                    </div>
                  </div>
                </CarouselItem>
              </CarouselContent>
              <div className="hidden sm:block">
                <CarouselPrevious className="left-4 bg-white/80 hover:bg-white text-[#8e6e55] border-[#e0d2c6]" />
                <CarouselNext className="right-4 bg-white/80 hover:bg-white text-[#8e6e55] border-[#e0d2c6]" />
              </div>
            </Carousel>

            {/* Mobile carousel indicators */}
            <div className="flex justify-center mt-4 gap-2 sm:hidden">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-2 w-2 rounded-full bg-[#8e6e55]/30" />
              ))}
              <div className="h-2 w-6 rounded-full bg-[#8e6e55]" />
            </div>
          </div>
        </section>

        {/* Hero Section */}
        <section className="bg-[#f4eae6] py-12 md:py-20">
          <div className="container grid gap-8 md:grid-cols-2 items-center">
            <div className="space-y-6 text-center md:text-left">
              <h1 className="text-3xl md:text-5xl font-bold text-[#8e6e55] leading-tight">
                Your Smile Deserves The Best Care
              </h1>
              <p className="text-lg text-[#8e6e55]/80">
                At SmileBright Dental, we provide comprehensive dental care with a gentle touch. Your comfort and oral
                health are our top priorities.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                <Button className="bg-[#8e6e55] hover:bg-[#7d5e45] text-white text-base px-6 py-6 h-auto">
                  Book Appointment
                </Button>
                <Button variant="outline" className="border-[#8e6e55] text-[#8e6e55] text-base px-6 py-6 h-auto">
                  Learn More
                </Button>
              </div>
            </div>
            <div className="rounded-lg overflow-hidden shadow-lg mt-6 md:mt-0">
              <img
                src="/placeholder.svg?height=600&width=800"
                alt="Dentist with patient"
                className="w-full h-auto object-cover"
              />
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="py-12 md:py-16 bg-white">
          <div className="container px-4 md:px-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
              <div className="flex flex-col items-center text-center p-6 bg-[#e5d6ca] rounded-lg shadow-sm transform transition-transform duration-300 hover:scale-105">
                <div className="h-14 w-14 rounded-full bg-[#8e6e55]/10 flex items-center justify-center mb-4">
                  <Calendar className="h-7 w-7 text-[#8e6e55]" />
                </div>
                <h3 className="text-xl font-medium text-[#8e6e55] mb-2">Convenient Scheduling</h3>
                <p className="text-[#8e6e55]/80">Easy online booking for your dental appointments</p>
              </div>
              <div className="flex flex-col items-center text-center p-6 bg-[#e5d6ca] rounded-lg shadow-sm transform transition-transform duration-300 hover:scale-105">
                <div className="h-14 w-14 rounded-full bg-[#8e6e55]/10 flex items-center justify-center mb-4">
                  <Users className="h-7 w-7 text-[#8e6e55]" />
                </div>
                <h3 className="text-xl font-medium text-[#8e6e55] mb-2">Family Friendly</h3>
                <p className="text-[#8e6e55]/80">Dental care for patients of all ages</p>
              </div>
              <div className="flex flex-col items-center text-center p-6 bg-[#e5d6ca] rounded-lg shadow-sm transform transition-transform duration-300 hover:scale-105">
                <div className="h-14 w-14 rounded-full bg-[#8e6e55]/10 flex items-center justify-center mb-4">
                  <Clock className="h-7 w-7 text-[#8e6e55]" />
                </div>
                <h3 className="text-xl font-medium text-[#8e6e55] mb-2">Emergency Care</h3>
                <p className="text-[#8e6e55]/80">Same-day appointments for dental emergencies</p>
              </div>
            </div>
          </div>
        </section>

        {/* Services */}
        <section id="services" className="py-12 md:py-16 bg-[#f4eae6]">
          <div className="container px-4 md:px-6">
            <div className="text-center mb-10 md:mb-12">
              <h2 className="text-3xl font-bold text-[#8e6e55] mb-4">Our Services</h2>
              <p className="text-[#8e6e55]/80 max-w-2xl mx-auto">
                We offer a comprehensive range of dental services to keep your smile healthy and beautiful.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
              {[
                {
                  title: "General Dentistry",
                  description: "Regular check-ups, cleanings, and preventive care to maintain oral health.",
                },
                {
                  title: "Cosmetic Dentistry",
                  description: "Teeth whitening, veneers, and other procedures to enhance your smile.",
                },
                {
                  title: "Orthodontics",
                  description: "Braces and aligners to straighten teeth and correct bite issues.",
                },
                {
                  title: "Oral Surgery",
                  description: "Tooth extractions, wisdom teeth removal, and other surgical procedures.",
                },
                {
                  title: "Pediatric Dentistry",
                  description: "Gentle dental care tailored specifically for children.",
                },
                {
                  title: "Restorative Dentistry",
                  description: "Fillings, crowns, bridges, and implants to restore damaged teeth.",
                },
              ].map((service, index) => (
                <Card
                  key={index}
                  className="bg-white border-[#e0d2c6] shadow-sm transform transition-transform duration-300 hover:shadow-md"
                >
                  <CardHeader>
                    <CardTitle className="text-[#8e6e55]">{service.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-[#8e6e55]/80 text-base">{service.description}</CardDescription>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* About */}
        <section id="about" className="py-16 bg-white">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="rounded-lg overflow-hidden">
                <img
                  src="/placeholder.svg?height=600&width=800"
                  alt="Our dental team"
                  className="w-full h-auto object-cover"
                />
              </div>
              <div className="space-y-6">
                <h2 className="text-3xl font-bold text-[#8e6e55]">About Our Practice</h2>
                <p className="text-[#8e6e55]/80">
                  Founded in 2005, SmileBright Dental has been providing exceptional dental care to our community for
                  over 15 years. Our team of experienced dentists and hygienists are committed to delivering
                  personalized care in a comfortable environment.
                </p>
                <p className="text-[#8e6e55]/80">
                  We use the latest dental technology and techniques to ensure that our patients receive the highest
                  quality care. Our modern facility is designed with your comfort in mind, and we strive to make every
                  visit a positive experience.
                </p>
                <Button className="bg-[#8e6e55] hover:bg-[#7d5e45] text-white">Meet Our Team</Button>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section id="testimonials" className="py-12 md:py-16 bg-[#e5d6ca]">
          <div className="container px-4 md:px-6">
            <div className="text-center mb-10 md:mb-12">
              <h2 className="text-3xl font-bold text-[#8e6e55] mb-4">What Our Patients Say</h2>
              <p className="text-[#8e6e55]/80 max-w-2xl mx-auto">
                Don't just take our word for it. Here's what our patients have to say about their experience at
                SmileBright Dental.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
              {[
                {
                  name: "Sarah Johnson",
                  quote:
                    "I've been coming to SmileBright for years and have always received excellent care. The staff is friendly and professional, and Dr. Miller is the best dentist I've ever had.",
                },
                {
                  name: "Michael Thompson",
                  quote:
                    "As someone who used to be terrified of dental visits, I can't recommend SmileBright enough. They made me feel comfortable and at ease throughout my treatment.",
                },
                {
                  name: "Emily Rodriguez",
                  quote:
                    "The entire team at SmileBright is amazing! They're thorough, gentle, and take the time to explain everything. My whole family comes here now.",
                },
              ].map((testimonial, index) => (
                <Card
                  key={index}
                  className="bg-white border-[#e0d2c6] shadow-md transform transition-transform duration-300 hover:scale-102"
                >
                  <CardContent className="pt-8 pb-6 px-6">
                    <div className="flex items-center mb-4">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-5 w-5 fill-[#8e6e55] text-[#8e6e55]" />
                      ))}
                    </div>
                    <p className="text-[#8e6e55]/80 mb-5 italic">"{testimonial.quote}"</p>
                    <p className="font-medium text-[#8e6e55]">- {testimonial.name}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Contact */}
        <section id="contact" className="py-12 md:py-16 bg-white">
          <div className="container px-4 md:px-6">
            <div className="grid md:grid-cols-2 gap-10 md:gap-12">
              <div className="space-y-6">
                <h2 className="text-3xl font-bold text-[#8e6e55]">Contact Us</h2>
                <p className="text-[#8e6e55]/80">
                  We're here to answer any questions you may have about our dental services. Reach out to us and we'll
                  respond as soon as we can.
                </p>
                <div className="space-y-5">
                  <div className="flex items-start gap-3">
                    <MapPin className="h-5 w-5 text-[#8e6e55] mt-1" />
                    <span className="text-[#8e6e55]/80">123 Dental Street, Cityville, State 12345</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="h-5 w-5 text-[#8e6e55]" />
                    <span className="text-[#8e6e55]/80">(555) 123-4567</span>
                  </div>
                  <div className="flex items-start gap-3">
                    <Clock className="h-5 w-5 text-[#8e6e55] mt-1" />
                    <div className="text-[#8e6e55]/80">
                      <p>Monday - Friday: 8:00 AM - 5:00 PM</p>
                      <p>Saturday: 9:00 AM - 2:00 PM</p>
                      <p>Sunday: Closed</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-[#e5d6ca] p-6 md:p-8 rounded-lg shadow-md">
                <h3 className="text-xl font-medium text-[#8e6e55] mb-5">Request an Appointment</h3>
                <form className="space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div className="space-y-2">
                      <label htmlFor="first-name" className="text-sm font-medium text-[#8e6e55]">
                        First Name
                      </label>
                      <input
                        id="first-name"
                        className="w-full px-4 py-3 border border-[#e0d2c6] rounded-md focus:outline-none focus:ring-2 focus:ring-[#8e6e55]"
                        type="text"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="last-name" className="text-sm font-medium text-[#8e6e55]">
                        Last Name
                      </label>
                      <input
                        id="last-name"
                        className="w-full px-4 py-3 border border-[#e0d2c6] rounded-md focus:outline-none focus:ring-2 focus:ring-[#8e6e55]"
                        type="text"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium text-[#8e6e55]">
                      Email
                    </label>
                    <input
                      id="email"
                      className="w-full px-4 py-3 border border-[#e0d2c6] rounded-md focus:outline-none focus:ring-2 focus:ring-[#8e6e55]"
                      type="email"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="phone" className="text-sm font-medium text-[#8e6e55]">
                      Phone
                    </label>
                    <input
                      id="phone"
                      className="w-full px-4 py-3 border border-[#e0d2c6] rounded-md focus:outline-none focus:ring-2 focus:ring-[#8e6e55]"
                      type="tel"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="message" className="text-sm font-medium text-[#8e6e55]">
                      Message
                    </label>
                    <textarea
                      id="message"
                      className="w-full px-4 py-3 border border-[#e0d2c6] rounded-md focus:outline-none focus:ring-2 focus:ring-[#8e6e55]"
                      rows={4}
                    ></textarea>
                  </div>
                  <Button className="w-full bg-[#8e6e55] hover:bg-[#7d5e45] text-white py-6 h-auto text-base">
                    Submit Request
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-[#8e6e55] text-white py-12">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Tooth className="h-6 w-6" />
                <span className="text-xl font-bold">SmileBright Dental</span>
              </div>
              <p className="text-white/80">Providing quality dental care for the whole family.</p>
            </div>
            <div>
              <h3 className="text-lg font-medium mb-4">Quick Links</h3>
              <ul className="space-y-3">
                <li>
                  <Link href="#" className="text-white/80 hover:text-white">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="#services" className="text-white/80 hover:text-white">
                    Services
                  </Link>
                </li>
                <li>
                  <Link href="#about" className="text-white/80 hover:text-white">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="#testimonials" className="text-white/80 hover:text-white">
                    Testimonials
                  </Link>
                </li>
                <li>
                  <Link href="#contact" className="text-white/80 hover:text-white">
                    Contact
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-medium mb-4">Services</h3>
              <ul className="space-y-3">
                <li>
                  <Link href="#" className="text-white/80 hover:text-white">
                    General Dentistry
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-white/80 hover:text-white">
                    Cosmetic Dentistry
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-white/80 hover:text-white">
                    Orthodontics
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-white/80 hover:text-white">
                    Oral Surgery
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-white/80 hover:text-white">
                    Pediatric Dentistry
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-medium mb-4">Contact</h3>
              <ul className="space-y-3">
                <li className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 flex-shrink-0" />
                  <span className="text-white/80">123 Dental Street, Cityville</span>
                </li>
                <li className="flex items-center gap-2">
                  <Phone className="h-5 w-5 flex-shrink-0" />
                  <span className="text-white/80">(555) 123-4567</span>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/20 mt-8 pt-8 text-center text-white/60">
            <p>&copy; {new Date().getFullYear()} SmileBright Dental. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

